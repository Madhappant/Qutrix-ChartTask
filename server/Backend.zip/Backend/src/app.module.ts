import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ChartModule } from './chart/chart.module';

@Module({
  imports: [
    MongooseModule.forRoot('mongodb+srv://dhanushmass371:mass123@chart0.0rfacfz.mongodb.net/'),
    ChartModule,
  ],
})
export class AppModule {}