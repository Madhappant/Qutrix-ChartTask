import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Chart, ChartDocument } from './chart.schema';
import { CreateChartDto } from './dto/create-chart.dto';

@Injectable()
export class ChartService {
  constructor(@InjectModel(Chart.name) private chartModel: Model<ChartDocument>) {}

  create(dto: CreateChartDto) {
    const created = new this.chartModel(dto);
    return created.save();
  }

  findAll() {
    return this.chartModel.find().exec();
  }

  findOne(id: string) {
    return this.chartModel.findById(id).exec();
  }

  update(id: string, dto: CreateChartDto) {
    return this.chartModel.findByIdAndUpdate(id, dto, { new: true });
  }

  remove(id: string) {
    return this.chartModel.findByIdAndDelete(id);
  }
}