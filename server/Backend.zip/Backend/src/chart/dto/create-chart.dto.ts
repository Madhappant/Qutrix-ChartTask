export class CreateChartDto {
  label: string;
  xData: number[];
  yData: number[];
}