import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type ChartDocument = HydratedDocument<Chart>;

@Schema()
export class Chart {
  @Prop({ required: true })
  label: string;

  @Prop({ type: [Number], required: true })
  xData: number[];

  @Prop({ type: [Number], required: true })
  yData: number[];
}

export const ChartSchema = SchemaFactory.createForClass(Chart);