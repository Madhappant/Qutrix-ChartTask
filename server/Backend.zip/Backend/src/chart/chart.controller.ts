import { Controller, Get, Post, Put, Delete, Param, Body } from '@nestjs/common';
import { ChartService } from './chart.service';
import { CreateChartDto } from './dto/create-chart.dto';

@Controller('chart')
export class ChartController {
  constructor(private readonly chartService: ChartService) {}

  @Post()
  create(@Body() dto: CreateChartDto) {
    return this.chartService.create(dto);
  }

  @Get()
  findAll() {
    return this.chartService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.chartService.findOne(id);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() dto: CreateChartDto) {
    return this.chartService.update(id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.chartService.remove(id);
  }
}